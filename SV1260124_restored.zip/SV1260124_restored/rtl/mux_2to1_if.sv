// (c) Technion IIT, Department of Electrical Engineering 2018 

// Implements mux 4=>1 with if statement
// combinatorial

module mux_2to1_if 	
 ( 
   input logic [1:0] datain,
	input logic select,
	output logic outd
	);

//-------------------------------------------------------------------------
// &&&&&&&&&&&&&&  fill your code and paste into the report
//-------------------------------------------------------------------------
	always_comb 
	begin 
		if (select==2'b00) begin
			outd=datain[0];
		end
		else begin
			outd=datain[1];
		end
	end
//--------------------------------------------------------------------------
// &&&&&&&&&&&&&&  end of paste into the report 
//--------------------------------------------------------------------------			


endmodule

